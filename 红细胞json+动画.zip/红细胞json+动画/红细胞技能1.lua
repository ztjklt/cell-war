-- Lua 5.4. Supply decoded JSON to new(config), or use the included default config.
local M = {}
M.config = {
    fps = 5, default = "搬运",
    states = {
        ["待机"] = {path="assets/红细胞技能1/搬运/", start=1, ["end"]=1, loop=true},
        ["搬运"] = {path="assets/红细胞技能1/搬运/", start=1, ["end"]=6, loop=false},
        ["持盒"] = {path="assets/红细胞技能1/搬运/", start=6, ["end"]=6, loop=true}
    }
}
function M.play(player, name)
    assert(player.config.states[name], "unknown animation state")
    player.state = name
    player.elapsed = 0
    player.finished = false
end
function M.new(config)
    config = config or M.config
    assert(type(config.fps)=="number" and config.fps>0, "fps must be positive")
    local player = {config=config}
    M.play(player, config.default)
    return player
end
function M.update(player, dt)
    assert(type(dt)=="number" and dt>=0, "dt must be nonnegative seconds")
    if player.finished then return end
    local state=player.config.states[player.state]
    local count=state["end"]-state.start+1
    local duration=count/player.config.fps
    player.elapsed=player.elapsed+dt
    if state.loop then
        player.elapsed=player.elapsed%duration
    elseif player.elapsed>=duration then
        player.elapsed=duration
        player.finished=true
    end
end
function M.frame(player)
    local state=player.config.states[player.state]
    local index=math.min(state["end"], state.start+math.floor(player.elapsed*player.config.fps))
    return state.path..string.format("%03d.png",index),index
end
-- Supply your engine's transparent PNG drawing function.
-- drawImage(path, x, y, width, height)
function M.draw(player, drawImage, x, y, width, height)
    local path=M.frame(player)
    return drawImage(path,x or 0,y or 0,width or 384,height or 358)
end
return M
