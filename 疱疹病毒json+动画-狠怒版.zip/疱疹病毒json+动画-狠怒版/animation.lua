-- LÖVE 11.x animation module. Coordinates x,y are the fixed character center.
local Animation = {}
Animation.__index = Animation
function Animation.new(root, config)
  local self = setmetatable({}, Animation)
  self.config = config or {fps=10, default="attack", states={attack={path="frames/attack", start=1, ["end"]=6, loop=true}}}
  self.root = root or ""
  self.images = {}
  for name,state in pairs(self.config.states) do
    self.images[name] = {}
    for i=state.start,state["end"] do
      local path = (self.root == "" and "" or self.root .. "/") .. state.path .. "/" .. string.format("%03d.png",i)
      self.images[name][#self.images[name]+1] = love.graphics.newImage(path)
    end
  end
  self:play(self.config.default)
  return self
end
function Animation:play(state)
  assert(self.images[state], "Unknown animation state: " .. tostring(state))
  self.state, self.time, self.index, self.finished = state, 0, 1, false
end
function Animation:update(dt)
  if self.finished then return end
  self.time = self.time + math.max(0,dt)
  local count = #self.images[self.state]
  local index = math.floor(self.time * self.config.fps)
  if self.config.states[self.state].loop then
    self.index = index % count + 1
  else
    self.index = math.min(index+1,count)
    self.finished = index >= count
  end
end
function Animation:draw(x,y,scale)
  local img = self.images[self.state][self.index]
  love.graphics.draw(img,x,y,0,scale or 1,scale or 1,img:getWidth()/2,img:getHeight()/2)
end
return Animation
