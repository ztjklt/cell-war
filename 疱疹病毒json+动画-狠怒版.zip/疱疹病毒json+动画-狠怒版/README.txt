疱疹病毒json+动画
六帧主动向右撞击，10 fps，0.6 秒循环。主体保持画布中心，保留周围速度残影和碰撞效果。
animation.webp：透明无损循环动画。
sprite.png：3列×2行透明精灵图，每帧640×640。
frames/attack/001.png—006.png：透明单帧。
animation.json：fps、default、states，路径相对于本资源包；start/end 均包含，帧号从1开始。
frame_params.json：画布、中心锚点、精灵图矩形、帧时长。
animation.lua：LÖVE 11.x调用模块；普通Lua环境需要接入自己的图片绘制API。
preview.html：浏览器直接打开查看WebP；preview.gif为白底预览，正式资源保持透明。
Lua示例：
local Animation=require("animation")
function love.load() anim=Animation.new("") end
function love.update(dt) anim:update(dt) end
function love.draw() anim:draw(love.graphics.getWidth()/2,love.graphics.getHeight()/2) end
可将解码后的animation.json作为Animation.new(root, config)的第二个参数。

狠怒版：去掉笑嘴，动作中咬牙怒视，保留速度残影和碰撞效果。
