# 巨噬细胞json+动画

包含透明动画 WebP、PNG 精灵图、16 张独立 PNG、帧参数、Lua 模块和播放配置。

`巨噬细胞.json`：fps 为 11.11111111111111（每帧 90 ms）；default 为“吞噬”。
states 中“吞噬”的 path 为相对资源包根目录的 ./png，start=1，end=16，loop=true。
帧号包含首尾，图片命名为 001.png 至 016.png。只有已制作的“吞噬”状态。
loop=false 时，Lua 模块播放一次后停留在最后一帧。

`帧参数.json`：独立 PNG 为 400×400；精灵图为 1024×1024、4×4 排列、每格 256×256。

Lua 示例（模块路径按项目放置位置调整）：
```lua
local animation = require("巨噬细胞技能1")
local frame, pngPath, x, y, width, height = animation.frameAt(elapsedSeconds)
-- 可加载 pngPath，或从 animation.spriteSheet 中绘制 x,y,width,height 区域。
```

Lua 模块负责计算帧与坐标，实际绘制使用项目引擎接口。
