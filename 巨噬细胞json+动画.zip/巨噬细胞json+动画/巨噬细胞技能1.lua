-- Paths are relative to this resource package. Frame numbering is 1-based.
local animation = {
    fps = 1000 / 90,
    default = "吞噬",
    states = { ["吞噬"] = { path = "./png", start = 1, ["end"] = 16, loop = true } },
    spriteSheet = "巨噬细胞技能1.png",
    columns = 4, frameWidth = 256, frameHeight = 256,
}
function animation.frameAt(elapsedSeconds, stateName)
    local state = assert(animation.states[stateName or animation.default], "Unknown animation state")
    local count = state["end"] - state.start + 1
    local step = math.floor(math.max(0, elapsedSeconds) * animation.fps)
    if state.loop then step = step % count else step = math.min(step, count - 1) end
    local frame = state.start + step
    local index = frame - 1
    return frame, string.format("%s/%03d.png", state.path, frame),
        (index % animation.columns) * animation.frameWidth,
        math.floor(index / animation.columns) * animation.frameHeight,
        animation.frameWidth, animation.frameHeight
end
return animation
