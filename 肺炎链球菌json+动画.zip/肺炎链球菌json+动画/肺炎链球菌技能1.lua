-- UTF-8. dt is seconds; frame numbering starts at 1.
-- Pass a decoded animation JSON to new(root, config), or use built-in defaults.
local M = {
    fps=8, default="skill1",
    states={
        idle={path="frames/skill1",start=1,["end"]=1,loop=true},
        skill1={path="frames/skill1",start=1,["end"]=6,loop=true},
    },
    texture="肺炎链球菌技能1.png",
    frameWidth=640,frameHeight=512,columns=3,rows=2,
}

function M.new(root, config)
    local c=config or M
    assert(type(c.fps)=="number" and c.fps>0, "fps must be positive")
    assert(c.states and c.states[c.default], "default state must exist")
    local p={root=root or ".",config=c,state=c.default,time=0,playing=true}
    function p:frame()
        local s=self.config.states[self.state]
        local count=s["end"]-s.start+1
        assert(count>0, "invalid frame range")
        local offset=math.floor(self.time*self.config.fps+1e-9)
        if s.loop then offset=offset%count else offset=math.min(offset,count-1) end
        local index=s.start+offset
        return {
            index=index,path=self.root.."/"..s.path.."/"..index..".png",
            texture=self.root.."/"..M.texture,
            x=((index-1)%M.columns)*M.frameWidth,
            y=math.floor((index-1)/M.columns)*M.frameHeight,
            width=M.frameWidth,height=M.frameHeight,
            anchorX=0.5,anchorY=0.5,
            finished=not s.loop and self.time>=count/self.config.fps,
        }
    end
    function p:setState(name)
        assert(self.config.states[name], "Unknown animation state: "..tostring(name))
        self.state=name;self.time=0;self.playing=true
        return self:frame()
    end
    function p:update(dt)
        local s=self.config.states[self.state]
        local duration=(s["end"]-s.start+1)/self.config.fps
        if self.playing then
            self.time=self.time+math.max(0,dt or 0)
            if s.loop then self.time=self.time%duration
            elseif self.time>=duration then self.time=duration;self.playing=false end
        end
        return self:frame()
    end
    function p:pause() self.playing=false end
    function p:play() self.playing=true end
    function p:reset() self.time=0;self.playing=true;return self:frame() end
    return p
end
return M
