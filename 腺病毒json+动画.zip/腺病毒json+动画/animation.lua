-- Love2D module. Pass decoded 动画.json and the resource directory.
local Animation = {}; Animation.__index = Animation
function Animation.new(config, base)
  local self=setmetatable({config=config,base=base or '.',elapsed=0},Animation)
  self:setState(config.default); return self
end
function Animation:setState(name)
  local s=assert(self.config.states[name], 'Unknown state: '..name)
  self.state=s; self.name=name; self.images={}; self.index=1; self.elapsed=0; self.finished=false
  for n=s.start,s['end'] do
    self.images[#self.images+1]=love.graphics.newImage(self.base..'/'..s.path..'/'..string.format('%03d.png',n))
  end
end
function Animation:update(dt)
  if self.finished then return end
  self.elapsed=self.elapsed+dt
  local step=1/self.config.fps
  while self.elapsed>=step do
    self.elapsed=self.elapsed-step
    if self.index<#self.images then self.index=self.index+1
    elseif self.state.loop then self.index=1
    else self.finished=true; self.elapsed=0; break end
  end
end
-- x,y is the fixed canvas center. The sprite's horizontal center never changes.
function Animation:draw(x,y,scale)
  local img=self.images[self.index]; scale=scale or 1
  love.graphics.draw(img,x,y,0,scale,scale,img:getWidth()/2,img:getHeight()/2)
end
return Animation
