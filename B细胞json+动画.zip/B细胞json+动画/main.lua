-- LÖVE example: unzip this package and open its folder with LÖVE.
local Skill = require("b_cell_skill_1")
local animation
function love.load()
  love.window.setTitle("B细胞技能1")
  love.window.setMode(720, 720)
  animation = Skill.newLove()
end
function love.update(dt)
  animation:update(dt)
end
function love.draw()
  love.graphics.clear(0.15, 0.17, 0.21, 1)
  animation:draw(love.graphics.getWidth() / 2,
    love.graphics.getHeight() / 2, 1)
end
