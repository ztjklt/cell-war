-- Engine-independent animation timing; optional LÖVE renderer below.
local M = {}
local Player = {}
Player.__index = Player
local moduleName = ...
local prefix = type(moduleName) == "string" and moduleName:match("^(.*%.)") or ""
local defaultData = require(prefix .. "b_cell_skill_1_frames")

function M.new(options)
  options = options or {}
  local data = options.data or defaultData
  local self = setmetatable({data=data, elapsed=0, playing=true,
    speed=options.speed or 1, renderer=options.renderer}, Player)
  assert(self.speed >= 0, "speed must be non-negative")
  return self
end

function Player:update(dt)
  assert(type(dt) == "number" and dt >= 0, "dt must be seconds >= 0")
  if self.playing then
    self.elapsed = (self.elapsed + dt * self.speed) % self.data.cycleDuration
  end
end

function Player:getFrameIndex()
  return math.min(self.data.frameCount,
    math.floor((self.elapsed + 1e-10) / self.data.duration) + 1)
end

function Player:getFrame()
  local index = self:getFrameIndex()
  return self.data.frames[index], index
end

function Player:pause() self.playing = false end
function Player:play() self.playing = true end
function Player:reset() self.elapsed = 0 end
function Player:setSpeed(speed)
  assert(type(speed) == "number" and speed >= 0, "speed must be non-negative")
  self.speed = speed
end

-- renderer(frame, x, y, scale, data, frameIndex)
-- x,y identify the fixed face anchor, not the changing flower bounds.
function Player:draw(x, y, scale)
  assert(self.renderer, "provide options.renderer or use newLove")
  local frame, index = self:getFrame()
  self.renderer(frame, x or 0, y or 0, scale or 1, self.data, index)
end

function M.newLove(options)
  options = options or {}
  assert(love and love.graphics, "newLove requires LÖVE")
  local data = options.data or defaultData
  local image = love.graphics.newImage(options.imagePath or data.spriteSheet)
  local quads = {}
  for i, f in ipairs(data.frames) do
    quads[i] = love.graphics.newQuad(f.x, f.y, f.width, f.height,
      data.sheetWidth, data.sheetHeight)
  end
  local player = M.new({data=data, speed=options.speed,
    renderer=function(frame, x, y, scale, d, index)
      love.graphics.draw(image, quads[index], x, y, 0, scale, scale,
        d.anchorX, d.anchorY)
    end})
  player.image, player.quads = image, quads
  return player
end


-- JSON-driven PNG sequence player. Pass an already decoded config table.
local StatePlayer = {}
StatePlayer.__index = StatePlayer
function M.newState(config, options)
  options = options or {}
  assert(type(config) == "table" and config.fps > 0, "config.fps must be > 0")
  local self = setmetatable({config=config, elapsed=0, playing=true,
    renderer=options.renderer, speed=options.speed or 1}, StatePlayer)
  assert(self.speed >= 0, "speed must be non-negative")
  self:setState(options.state or config.default)
  return self
end
function StatePlayer:setState(name)
  local state = assert(self.config.states[name], "unknown state: " .. tostring(name))
  assert(state.start >= 1 and state["end"] >= state.start, "invalid frame range")
  self.stateName, self.state = name, state
  self.elapsed, self.playing = 0, true
  self.count = state["end"] - state.start + 1
  self.cycle = self.count / self.config.fps
end
function StatePlayer:update(dt)
  assert(type(dt) == "number" and dt >= 0, "dt must be seconds >= 0")
  if not self.playing then return end
  self.elapsed = self.elapsed + dt * self.speed
  if self.state.loop then
    self.elapsed = self.elapsed % self.cycle
  elseif self.elapsed >= self.cycle then
    self.elapsed, self.playing = self.cycle, false
  end
end
function StatePlayer:getFrameIndex()
  local offset = math.min(self.count - 1,
    math.floor(self.elapsed * self.config.fps + 1e-10))
  return self.state.start + offset
end
function StatePlayer:getFramePath()
  return self.state.path:gsub("/$", "") .. "/" .. self:getFrameIndex() .. ".png"
end
function StatePlayer:pause() self.playing = false end
function StatePlayer:play() self.playing = true end
function StatePlayer:reset() self.elapsed, self.playing = 0, true end
function StatePlayer:draw(x, y, scale)
  assert(self.renderer, "provide renderer or use newJsonLove")
  self.renderer(self:getFramePath(), x or 0, y or 0, scale or 1,
    self:getFrameIndex(), self.stateName)
end
-- decode is a caller-supplied JSON decoder, e.g. json.decode.
-- PNG paths resolve relative to the JSON file's directory.
function M.newJsonLove(jsonPath, decode, options)
  options = options or {}
  assert(love and love.graphics and love.filesystem, "newJsonLove requires LÖVE")
  assert(type(decode) == "function", "pass your JSON decoder function")
  local content, err = love.filesystem.read(jsonPath)
  assert(content, err)
  local config = decode(content)
  local base = jsonPath:match("^(.*[/])") or ""
  local images = {}
  local player = M.newState(config, {state=options.state, speed=options.speed,
    renderer=function(path, x, y, scale)
      local fullPath = base .. path
      if not images[fullPath] then images[fullPath] = love.graphics.newImage(fullPath) end
      love.graphics.draw(images[fullPath], x, y, 0, scale, scale,
        options.anchorX or defaultData.anchorX,
        options.anchorY or defaultData.anchorY)
    end})
  player.images = images
  return player
end

return M
