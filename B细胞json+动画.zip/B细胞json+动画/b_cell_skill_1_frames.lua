return {
  name = "B细胞技能1",
  animation = "B细胞技能1.webp",
  spriteSheet = "B细胞技能1_精灵图.png",
  sheetWidth = 1728, sheetHeight = 1152,
  frameWidth = 576, frameHeight = 576,
  frameCount = 6, duration = 0.15, cycleDuration = 0.9,
  loop = true, anchorX = 288, anchorY = 285,
  frames = {
    {x=0, y=0, width=576, height=576},
    {x=576, y=0, width=576, height=576},
    {x=1152, y=0, width=576, height=576},
    {x=0, y=576, width=576, height=576},
    {x=576, y=576, width=576, height=576},
    {x=1152, y=576, width=576, height=576},
  }
}
