B细胞技能1资源包

文件：
B细胞技能1.webp：已压缩的透明循环动画，576×576，6帧。
B细胞技能1_精灵图.png：透明静态PNG精灵图，1728×1152，3列2行。
帧参数.json：帧坐标、尺寸、播放时长及固定锚点，供其他引擎读取。
b_cell_skill_1_frames.lua：Lua格式的帧参数，无需JSON库。
b_cell_skill_1.lua：通用Lua播放计时模块，附LÖVE绘制适配器。
main.lua：LÖVE调用示例。

动画参数：从左到右、先上后下；每帧150毫秒；一轮900毫秒；无限循环。
坐标从左上角开始，像素坐标从0开始；帧编号1至6。
固定锚点为每帧(288,285)，是双眼中心。绘制时让此锚点始终处于同一位置。

LÖVE：将本包解压至独立文件夹，用LÖVE打开文件夹即可运行main.lua。
现有LÖVE项目可放进assets/b_cell_skill_1目录，调用：
local Skill = require("assets.b_cell_skill_1.b_cell_skill_1")
local animation = Skill.newLove({imagePath="assets/b_cell_skill_1/B细胞技能1_精灵图.png"})
每次update(dt)调用animation:update(dt)，dt以秒为单位。
绘制时调用animation:draw(屏幕中心X,屏幕中心Y,缩放比例)。

其他Lua引擎：使用Skill.new({renderer=自定义绘图函数})。
renderer接收(frame,x,y,scale,data,index)，按frame裁切精灵图，
绘制左上角为(x-data.anchorX*scale,y-data.anchorY*scale)。
通用模块不依赖特定引擎，但需要在目标引擎中实现renderer。
程序播放使用PNG精灵图；动画WebP供支持该格式的界面直接显示。

注意：素材来自现有六帧生成图，已对齐双眼中心；绘制细节仍可能有轻微变化。

新增JSON配置：B细胞json+动画.json
fps = 6.666666666666667，等于每帧150毫秒；default = skill1。
states.skill1.path = png/skill1，是相对于JSON文件所在目录的路径。
start = 1，end = 6（包含第6帧），loop = true。
独立透明PNG按1.png至6.png命名，尺寸均为576×576。
PNG精灵图、WebP与独立PNG使用同一套居中帧。

Lua读取JSON调用示例（LÖVE，需项目已有的JSON解析器）：
local Skill = require("b_cell_skill_1")
local json = require("json") -- 使用你项目中的JSON解析器；本包不内置解析器。
local animation = Skill.newJsonLove("B细胞json+动画.json", json.decode)
在love.update(dt)中调用animation:update(dt)。
在love.draw()中调用animation:draw(画面中心X,画面中心Y,1)。
animation:setState("skill1")切换/重新播放状态。
loop=false时播放一次并停在最后一帧；loop=true时无限循环。
其他Lua引擎可将解析后的配置传给Skill.newState(config,{renderer=绘图函数})。
renderer接收(path,x,y,scale,frameIndex,stateName)。

main.lua继续提供无需JSON解析器的PNG精灵图播放示例。
素材与压缩包已验证；Lua模块未在实际游戏引擎中运行验证。
