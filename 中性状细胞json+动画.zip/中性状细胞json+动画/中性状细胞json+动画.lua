-- Lua 5.1+，update 参数单位：秒。无需第三方库。
local M = {}
M.config = {
  fps=7, default="skill1",
  states={skill1={path="frames/skill1/", start=1, ["end"]=6, loop=true}}
}
-- 可传入已由引擎 JSON 库解析的配置表。
function M.new(config, basePath)
  local c = config or M.config
  assert(type(c.fps)=="number" and c.fps>0, "fps must be positive")
  local p = {config=c, state=c.default, elapsed=0, playing=true}
  local prefix=basePath or ""
  if prefix~="" and prefix:sub(-1)~="/" then prefix=prefix.."/" end
  function p:setState(name)
    assert(self.config.states[name], "unknown animation state")
    self.state=name; self.elapsed=0; self.playing=true
  end
  function p:current()
    local s=assert(self.config.states[self.state], "unknown animation state")
    local count=s["end"]-s.start+1
    assert(count>0, "invalid frame range")
    local offset=math.floor(self.elapsed*self.config.fps)
    if s.loop then offset=offset%count else offset=math.min(offset,count-1) end
    local index=s.start+offset
    local path=s.path
    if path~="" and path:sub(-1)~="/" then path=path.."/" end
    return prefix..path..index..".png", index
  end
  function p:update(dt)
    local s=self.config.states[self.state]
    if self.playing then
      self.elapsed=self.elapsed+math.max(0,dt or 0)
      local duration=(s["end"]-s.start+1)/self.config.fps
      if s.loop then self.elapsed=self.elapsed%duration
      elseif self.elapsed>=duration then self.elapsed=duration; self.playing=false end
    end
    return self:current()
  end
  function p:pause() self.playing=false end
  function p:play() self.playing=true end
  function p:reset() self.elapsed=0; self.playing=true end
  p:setState(c.default)
  return p
end
return M
