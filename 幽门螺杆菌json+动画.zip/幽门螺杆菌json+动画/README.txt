幽门螺杆菌json+动画
默认 whip 状态，8 fps，6 帧，750 ms 无限循环。全部 PNG 为透明 RGBA。
animation.webp：无损透明循环动画。
spritesheet.png：3 列 × 2 行，单帧 640 × 540，按行排列。
frames/whip/001.png 至 006.png：独立帧。
animation.json：fps、default、states，路径相对资源包根目录。
frame-parameters.json：画布、精灵矩形、帧时间。
preview.html：直接打开查看动画。preview.png 为 APNG 动画备用预览。
animation.lua：通用播放器，不依赖具体引擎；宿主负责 JSON 解码、加载图片和绘制。
Lua 调用示例：
local Animation = require("animation")
local player = Animation.new(decodedJson, "资源包目录")
-- 每次更新，dt 单位为秒：
player:update(dt)
-- 加载/缓存 player:getFramePath()，在固定画布位置绘制。
-- 精灵图模式可用 player:getSpriteRect() 获取裁剪矩形。
非循环状态会停在末帧，finished 为 true；play(name) 可重新播放。
用内置 imagegen 生成原始帧，再注册合成；固定上半身、移除邻格碎片。
