-- Engine-independent Lua 5.1+ animation player. JSON decoding is supplied by host.
local Animation = {}
Animation.__index = Animation
function Animation.new(config, basePath)
  assert(config.fps and config.fps > 0, "fps must be positive")
  local self = setmetatable({config=config, basePath=basePath or "", elapsed=0}, Animation)
  self:play(config.default)
  return self
end
function Animation:play(name)
  local state = assert(self.config.states[name], "Unknown animation state")
  self.name, self.state, self.frame, self.elapsed, self.finished = name, state, state.start, 0, false
end
function Animation:update(dt)
  assert(dt >= 0, "dt is seconds and must be nonnegative")
  if self.finished then return end
  self.elapsed = self.elapsed + dt
  local count = self.state["end"] - self.state.start + 1
  local step = math.floor(self.elapsed * self.config.fps + 1e-9)
  if self.state.loop then
    self.frame = self.state.start + (step % count)
  else
    self.frame = self.state.start + math.min(step, count - 1)
    self.finished = step >= count
  end
end
function Animation:getFramePath()
  local prefix = self.basePath ~= "" and (self.basePath .. "/") or ""
  return prefix .. self.state.path .. "/" .. string.format("%03d.png", self.frame)
end
function Animation:getSpriteRect()
  local index = self.frame - 1
  return (index % 3) * 640, math.floor(index / 3) * 540, 640, 540
end
return Animation
