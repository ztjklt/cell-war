资源说明
动画：12帧，8 fps，1.5秒一轮，透明背景。第12帧与第1帧完全相同。
木桶水平中心固定在 x=256，底部固定在 y=450；所有帧512×512，渲染时不得按各帧可见区域重新居中。
animation.webp：无限循环透明动画。
spritesheet.png：4列×3行，从左到右，从上到下。
frames/001.png 至 012.png：独立透明帧。
animation.json：fps、default、states；path相对本资源包根目录；start/end从1计数且包含结束帧。
frame-parameters.json：帧尺寸、精灵图坐标、中心锚点和原图对齐偏移。
animation.lua：LÖVE 11.x调用模块，JSON解码器由宿主提供。
示例：local Animation=require('animation'); local json=require('json'); local config=json.decode(love.filesystem.read('animation.json')); player=Animation.new(config,'.')
love.update(dt) 中调用 player:update(dt)；love.draw() 中调用 player:draw(love.graphics.getWidth()/2, love.graphics.getHeight()*0.85,1)。
player:play('constrict')完整循环；idle静止；wrap缠绕；tighten收紧；release释放。后三者播一次后停在最后帧，player.finished为true。
preview.html：浏览器播放演示；preview.gif：聊天预览。
图像由内置imagegen生成，随后统一帧尺寸和中心锚点。
