-- LÖVE 11.x animation player. Pass decoded animation.json and resource root.
local Animation = {}
Animation.__index = Animation
function Animation.new(config, root)
  local self = setmetatable({config=config,root=root or '.',time=0,images={},finished=false},Animation)
  for _,state in pairs(config.states) do
    for i=state.start,state['end'] do
      local file=self.root..'/'..state.path..'/'..string.format('%03d.png',i)
      if not self.images[file] then self.images[file]=love.graphics.newImage(file) end
    end
  end
  self:play(config.default)
  return self
end
function Animation:play(name)
  assert(self.config.states[name], 'Unknown animation state: '..tostring(name))
  self.state=name;self.time=0;self.finished=false;self.frame=self.config.states[name].start
end
function Animation:update(dt)
  local state=self.config.states[self.state]
  self.time=self.time+math.max(0,dt)
  local count=state['end']-state.start+1
  local step=math.floor(self.time*self.config.fps)
  if not state.loop and step>=count then self.finished=true end
  self.frame=state.start+(state.loop and step%count or math.min(step,count-1))
end
-- x,y are the fixed barrel center and baseline. Never center each frame by its bounds.
function Animation:draw(x,y,scale)
  local state=self.config.states[self.state]
  local frame=self.frame or state.start
  local file=self.root..'/'..state.path..'/'..string.format('%03d.png',frame)
  scale=scale or 1
  love.graphics.draw(self.images[file],x,y,0,scale,scale,256,450)
end
return Animation

