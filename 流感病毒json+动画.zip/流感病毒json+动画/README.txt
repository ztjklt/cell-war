流感病毒动画资源包

animation.webp：透明循环动画，512×512，6帧，8fps，周期0.75秒。
sprite.png：透明PNG精灵图，1536×1024，3列×2行，按行从左到右。
frames/001.png～006.png：透明独立帧，统一512×512画布，中心锚点(256,256)。
animation.json：播放配置。path相对本资源包目录；帧号从1开始；文件名为三位数字。
frame-parameters.json：尺寸、精灵图区域、锚点、各帧时长。
animation.lua：适用于LÖVE 11.x的Lua播放模块；其他Lua引擎需替换图片加载与绘制接口。
preview.html：用浏览器打开可预览动画。

默认状态devour（吞噬）循环播放；idle（待机）只显示第1帧。
loop=true循环；loop=false播完后停留末帧。
末帧与首帧完全一致。各帧按可见轮廓中心对齐，保留膨胀与压缩变化。

Lua调用示例（config为你所用JSON解析器解码animation.json后的表）：
local Animation = require('animation')
local actor = Animation.new(config, '流感病毒json+动画')
-- love.update(dt) 中：actor:update(dt)
-- love.draw() 中：actor:draw(love.graphics.getWidth()/2, love.graphics.getHeight()/2)
-- 切换状态：actor:setState('idle') 或 actor:setState('devour')
