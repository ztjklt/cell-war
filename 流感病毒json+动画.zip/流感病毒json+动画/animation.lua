-- LÖVE 11.x module. Pass the decoded animation.json table to new().
local Animation = {}
Animation.__index = Animation

function Animation.new(config, basePath)
    assert(type(config.fps) == 'number' and config.fps > 0, 'fps must be positive')
    local self = setmetatable({config=config, base=basePath or '', cache={}, elapsed=0}, Animation)
    self:setState(config.default)
    return self
end

function Animation:setState(name)
    local state = assert(self.config.states[name], 'Unknown animation state: '..tostring(name))
    assert(state.start <= state['end'], 'Invalid frame range')
    self.state, self.name, self.frame, self.elapsed, self.finished = state, name, state.start, 0, false
    for i=state.start,state['end'] do
        local path = (self.base ~= '' and self.base..'/' or '')..state.path..'/'..string.format('%03d.png', i)
        if not self.cache[path] then self.cache[path] = love.graphics.newImage(path) end
    end
end

function Animation:update(dt)
    if self.finished then return end
    self.elapsed = self.elapsed + dt
    local steps = math.floor(self.elapsed * self.config.fps)
    if steps == 0 then return end
    self.elapsed = self.elapsed - steps / self.config.fps
    local count = self.state['end'] - self.state.start + 1
    local offset = self.frame - self.state.start + steps
    if self.state.loop then
        self.frame = self.state.start + offset % count
    else
        self.frame = math.min(self.state.start + offset, self.state['end'])
        self.finished = offset >= count
    end
end

function Animation:draw(centerX, centerY, scale)
    local path = (self.base ~= '' and self.base..'/' or '')..self.state.path..'/'..string.format('%03d.png', self.frame)
    local image = self.cache[path]
    love.graphics.draw(image, centerX, centerY, 0, scale or 1, scale or 1, 256, 256)
end

return Animation
