-- dt in seconds. rootPath points to the extracted package directory.
local Player = {}
Player.__index = Player
function Player.new(config, rootPath)
    assert(config.fps > 0, "fps must be positive")
    local self = setmetatable({config=config, rootPath=rootPath or "."}, Player)
    self:setState(config.default)
    return self
end
function Player:setState(name)
    local state = assert(self.config.states[name], "unknown state")
    assert(state.start <= state["end"], "invalid frame range")
    self.state, self.stateName, self.time = state, name, 0
    self.frame, self.playing = state.start, true
end
function Player:update(dt)
    assert(type(dt)=="number" and dt>=0, "dt must be nonnegative seconds")
    if not self.playing then return self:getFramePath() end
    self.time = self.time + dt
    local count = self.state["end"] - self.state.start + 1
    local duration = count / self.config.fps
    if self.state.loop then
        self.time = self.time % duration
    elseif self.time >= duration then
        self.frame, self.playing = self.state["end"], false
        return self:getFramePath()
    end
    local offset = math.min(count-1, math.floor(self.time * self.config.fps + 1e-9))
    self.frame = self.state.start + offset
    return self:getFramePath()
end
function Player:getFramePath()
    return self.rootPath .. "/" .. self.state.path .. "/" .. string.format("%03d.png", self.frame), self.frame
end
function Player:pause() self.playing = false end
function Player:play() self.playing = true end
function Player:reset() self:setState(self.stateName) end
-- drawImage(path, x, y, width, height) is provided by the host engine.
function Player:draw(drawImage, x, y, width, height)
    drawImage(self:getFramePath(), x, y, width or 512, height or 512)
end
return Player
