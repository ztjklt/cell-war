local Player = require("animation_player")
local config = require("animation_config")
local animation = Player.new(config, ".")
-- Call animation:update(dt) each tick; dt is seconds.
-- animation:draw(drawImage, x, y, 512, 512)
-- drawImage is your engine-specific image renderer.
return animation
