return {
  fps = 10,
  default = "吞噬",
  states = {
    ["吞噬"] = {path = "png/吞噬", start = 1, ["end"] = 6, loop = true},
  },
}
