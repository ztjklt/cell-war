-- UTF-8. dt is in seconds. Paths are relative to package root.
local M = {
    fps=8, default="skill1",
    states={skill1={path="frames/skill1",start=1,["end"]=6,loop=true}},
    texture="T细胞技能1.png", frameWidth=640, frameHeight=640, columns=3,
}
function M.new(root)
    local p={root=root or ".",state=M.default,time=0,playing=true}
    function p:setState(name)
        assert(M.states[name], "Unknown animation state: "..tostring(name))
        self.state=name;self.time=0;self.playing=true
        return self:frame()
    end
    function p:frame()
        local s=M.states[self.state]
        local count=s["end"]-s.start+1
        local offset=math.floor(self.time*M.fps+1e-9)
        if s.loop then offset=offset%count else offset=math.min(offset,count-1) end
        local index=s.start+offset
        return {index=index, path=self.root.."/"..s.path.."/"..index..".png",
            texture=self.root.."/"..M.texture,
            x=((index-1)%M.columns)*M.frameWidth,
            y=math.floor((index-1)/M.columns)*M.frameHeight,
            width=M.frameWidth,height=M.frameHeight,anchorX=0.5,anchorY=0.5,
            finished=not s.loop and self.time>=count/M.fps}
    end
    function p:update(dt)
        local s=M.states[self.state];local duration=(s["end"]-s.start+1)/M.fps
        if self.playing then
            self.time=self.time+math.max(0,dt or 0)
            if s.loop then self.time=self.time%duration
            elseif self.time>=duration then self.time=duration;self.playing=false end
        end
        return self:frame()
    end
    function p:pause() self.playing=false end
    function p:play() self.playing=true end
    function p:reset() self.time=0;self.playing=true;return self:frame() end
    return p
end
return M
