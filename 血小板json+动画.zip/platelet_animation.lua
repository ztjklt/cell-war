-- 血小板动画；传入已解析的 animation.json table。无第三方依赖。
local M = {}
M.config = {
    fps=5, default="hand_in_hand",
    states={ hand_in_hand={path="frames/hand_in_hand",start=1,["end"]=6,loop=true} }
}
M.width, M.height = 724, 362
M.sheet = "血小板精灵图.png"
M.webp = "血小板动画.webp"
local function finite(v) return type(v)=="number" and v==v and math.abs(v)<math.huge end

-- basePath 是资源包在项目中的根目录；不传则相对于当前资源目录。
function M.new(config, basePath)
    config = config or M.config
    assert(finite(config.fps) and config.fps>0, "fps must be positive")
    assert(type(config.states)=="table", "states required")
    for _,s in pairs(config.states) do
        assert(type(s.path)=="string" and finite(s.start) and finite(s["end"])
            and s.start>=1 and s.start%1==0 and s["end"]%1==0
            and s["end"]>=s.start and s["end"]<=6 and type(s.loop)=="boolean",
            "invalid state")
    end
    local prefix = basePath or ""
    if prefix~="" and prefix:sub(-1)~="/" then prefix=prefix.."/" end
    local p = { elapsed=0, playing=true, state=config.default }
    assert(config.states[p.state], "default state missing")
    function p:setState(name)
        assert(config.states[name], "unknown animation state")
        self.state, self.elapsed, self.playing = name, 0, true
    end
    function p:getFrame()
        local s=config.states[self.state]
        local count=s["end"]-s.start+1
        local offset=math.floor(self.elapsed*config.fps+1e-9)
        if s.loop then offset=offset%count else offset=math.min(offset,count-1) end
        local index=s.start+offset
        return prefix..s.path..string.format("/%03d.png",index), index,
            {x=((index-1)%2)*M.width,y=math.floor((index-1)/2)*M.height,
             width=M.width,height=M.height}
    end
    function p:update(dt)
        assert(finite(dt) and dt>=0,"dt must be finite and nonnegative")
        if self.playing then
            local s=config.states[self.state]
            local duration=(s["end"]-s.start+1)/config.fps
            self.elapsed=self.elapsed+dt
            if s.loop then self.elapsed=self.elapsed%duration
            elseif self.elapsed>=duration then
                self.elapsed=duration; self.playing=false
            end
        end
        return self:getFrame()
    end
    function p:pause() self.playing=false end
    function p:resume() self.playing=true end
    function p:reset() self:setState(self.state) end
    -- 整张精灵图绘制回调：drawRegion(texture,sx,sy,sw,sh,dx,dy,dw,dh)
    function p:draw(drawRegion,texture,centerX,centerY,scale)
        scale=scale or 1
        assert(type(drawRegion)=="function" and finite(scale) and scale>0,
            "drawRegion callback and positive scale required")
        local _,index,f=self:getFrame()
        local width,height=M.width*scale,M.height*scale
        drawRegion(texture,f.x,f.y,f.width,f.height,
            centerX-width/2,centerY-height/2,width,height)
        return index
    end
    return p
end
return M
