# 血小板json+动画

包含透明动画 WebP、透明 PNG 精灵图、6张逐帧 PNG、animation.json、frames.json 和 Lua 调用模块。
使用最新居中动画；统一为 5 fps，每帧 200 ms，一轮 1.2 秒，各格式与 Lua 时序一致。

animation.json：fps=每秒帧数；default=默认状态名称；states=状态集合。
当前只有 hand_in_hand（并排牵手）这一组动画。path 相对于资源包根目录，
start/end 为从1开始且包含结束帧的帧号；PNG 文件命名为001.png至006.png。
loop=true 循环；设为false则播放一次，停在末帧。
frames.json 包含精灵图帧区域、大小、时长及固定中心锚点(0.5,0.5)。

## Lua 使用

```lua
local Animation = require("platelet_animation") -- 按项目实际模块路径调整
-- 可以使用项目的 JSON 解码器解析 animation.json，然后传入：
-- local player = Animation.new(decodedConfig, "assets/血小板json+动画")
local player = Animation.new(nil, "assets/血小板json+动画") -- 内置相同默认配置
player:update(dt) -- 秒；暂停时不推进
local pngPath, frameIndex, region = player:getFrame()
-- 使用项目现有贴图加载与绘制 API 加载 pngPath 并绘制。
-- 或加载整张 Animation.sheet 精灵图后调用：
player:draw(drawRegion, texture, centerX, centerY, 0.5)
```

drawRegion(texture,sx,sy,sw,sh,dx,dy,dw,dh) 由宿主引擎提供。
源区域使用左上角原点、像素坐标；目标区域始终按中心锚点绘制。
贴图加载、JSON 文件读取/解码及绘制回调需接入项目现有 API。
修改 fps 后，Lua 和 PNG 序列按新帧率播放；WebP 为预渲染动画，需要重新导出才能同步。
Lua模块尚未在TapTap Maker原生运行环境中测试。此包未上传GitHub。
