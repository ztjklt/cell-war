local M = {}
M.config = {fps=5, default="skill1", states={
    idle={path="frames/skill1", start=1, ["end"]=1, loop=true},
    skill1={path="frames/skill1", start=1, ["end"]=6, loop=true},
}}
-- Pass decoded animation.json as options.config; no engine/JSON library dependency.
function M.new(options)
    options = options or {}
    local cfg = options.config or M.config
    assert(type(cfg.fps)=="number" and cfg.fps>0, "fps must be positive")
    local base = (options.basePath or "."):gsub("[/\\]+$", "")
    local player = {config=cfg, time=0, playing=true, basePath=base}
    function player:setState(name)
        local state = assert(self.config.states[name], "unknown animation state")
        assert(state.start>=1 and state["end"]>=state.start, "invalid frame range")
        self.stateName, self.state, self.time, self.playing = name, state, 0, true
    end
    function player:update(dt)
        assert(type(dt)=="number" and dt>=0, "dt must be nonnegative seconds")
        if not self.playing then return end
        local duration = (self.state["end"]-self.state.start+1)/self.config.fps
        self.time = self.time + dt
        if self.state.loop then self.time=self.time%duration
        elseif self.time>=duration then self.time=duration; self.playing=false end
    end
    function player:getFrame()
        local state=self.state
        local count=state["end"]-state.start+1
        local offset=math.floor(self.time*self.config.fps+1e-9)
        if state.loop then offset=offset%count else offset=math.min(offset,count-1) end
        local index=state.start+offset
        return {index=index,
            path=self.basePath.."/"..state.path.."/"..string.format("%03d.png",index),
            spriteSheet=self.basePath.."/树突状细胞技能1.png",
            x=((index-1)%3)*512, y=math.floor((index-1)/3)*512,
            width=512, height=512, anchorX=0.5, anchorY=0.5}
    end
    function player:reset() self:setState(self.stateName) end
    -- drawRegion(textureOrPath, sx, sy, sw, sh, dx, dy, dw, dh).
    -- Implement this callback using your engine's alpha-enabled texture renderer.
    function player:draw(drawRegion,centerX,centerY,width,height)
        width=width or 512; height=height or width
        local f=self:getFrame()
        drawRegion(options.texture or f.spriteSheet,f.x,f.y,f.width,f.height,
            centerX-width/2,centerY-height/2,width,height)
    end
    player:setState(options.state or cfg.default)
    return player
end
return M
